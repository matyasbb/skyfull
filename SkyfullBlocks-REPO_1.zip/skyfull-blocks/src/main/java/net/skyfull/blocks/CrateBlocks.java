package net.skyfull.blocks;

import org.bukkit.block.BlockFace;

/**
 * Definitions of the 8 custom crate blocks.
 *
 * Each crate is stored in the world as a BROWN_MUSHROOM_BLOCK with a unique
 * combination of "faces" (MultipleFacing). Mushroom-block face states are
 * STABLE (they are not recalculated on neighbour/redstone updates), so the
 * identity of a placed crate survives restarts and world updates with no
 * database. We deliberately pick face combinations that neither natural
 * huge-mushrooms nor a normally placed mushroom block (all faces = true)
 * ever produce, so vanilla mushrooms are never mistaken for crates.
 *
 * Bit order used for the mask: N=1, E=2, S=4, W=8, U=16, D=32.
 */
public final class CrateBlocks {

    public static final int COUNT = 8;

    /** Faces that must be TRUE for each crate (index 0 = crate #1). */
    private static final BlockFace[][] FACES = {
        { BlockFace.DOWN },                       // #1
        { BlockFace.NORTH },                      // #2
        { BlockFace.EAST },                       // #3
        { BlockFace.SOUTH },                      // #4
        { BlockFace.WEST },                       // #5
        { BlockFace.NORTH, BlockFace.SOUTH },     // #6
        { BlockFace.EAST,  BlockFace.WEST },      // #7
        { BlockFace.DOWN,  BlockFace.NORTH },     // #8
    };

    /** Display names for the give-items (feel free to rename in-game/anvil). */
    private static final String[] NAMES = {
        "§7Bedna §fCommon",
        "§aBedna Uncommon",
        "§9Bedna Rare",
        "§5Bedna Epic",
        "§6Bedna Legendary",
        "§cBedna Mythic",
        "§bBedna Seasonal",
        "§dBedna Vote",
    };

    private CrateBlocks() {}

    public static boolean valid(int id) {
        return id >= 1 && id <= COUNT;
    }

    public static BlockFace[] faces(int id) {
        return FACES[id - 1];
    }

    public static String name(int id) {
        return NAMES[id - 1];
    }

    /** Bit mask for a crate's face set. */
    public static int maskOf(int id) {
        int m = 0;
        for (BlockFace f : FACES[id - 1]) m |= bit(f);
        return m;
    }

    /** Returns crate id (1..8) for a given face-mask, or 0 if it is not a crate. */
    public static int idForMask(int mask) {
        for (int id = 1; id <= COUNT; id++) {
            if (maskOf(id) == mask) return id;
        }
        return 0;
    }

    public static int bit(BlockFace f) {
        return switch (f) {
            case NORTH -> 1;
            case EAST  -> 2;
            case SOUTH -> 4;
            case WEST  -> 8;
            case UP    -> 16;
            case DOWN  -> 32;
            default    -> 0;
        };
    }
}
