package net.skyfull.blocks;

import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Turns the give-item into the right custom block on place, and drops the
 * matching item back on break. Identity is carried entirely by the block's
 * mushroom face-state, so no storage is required.
 */
public final class BlockListener implements Listener {

    private final SkyfullBlocks plugin;

    public BlockListener(SkyfullBlocks plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        ItemStack hand = event.getItemInHand();
        if (hand == null) return;
        ItemMeta meta = hand.getItemMeta();
        if (meta == null) return;
        Integer id = meta.getPersistentDataContainer()
                .get(SkyfullBlocks.CRATE_KEY, PersistentDataType.INTEGER);
        if (id == null || !CrateBlocks.valid(id)) return;

        Block block = event.getBlockPlaced();
        BlockData data = org.bukkit.Material.BROWN_MUSHROOM_BLOCK.createBlockData();
        if (!(data instanceof MultipleFacing mf)) return;
        for (BlockFace f : mf.getAllowedFaces()) mf.setFace(f, false);
        for (BlockFace f : CrateBlocks.faces(id)) mf.setFace(f, true);
        // apply without triggering physics so the state is preserved verbatim
        block.setBlockData(mf, false);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() != org.bukkit.Material.BROWN_MUSHROOM_BLOCK) return;
        if (!(block.getBlockData() instanceof MultipleFacing mf)) return;

        int mask = 0;
        for (BlockFace f : mf.getAllowedFaces()) {
            if (mf.hasFace(f)) mask |= CrateBlocks.bit(f);
        }
        int id = CrateBlocks.idForMask(mask);
        if (id == 0) return; // a normal mushroom block, leave vanilla behaviour

        // this is one of our crate blocks -> drop the crate item instead
        event.setDropItems(false);
        if (event.getPlayer().getGameMode() != GameMode.CREATIVE) {
            block.getWorld().dropItemNaturally(
                    block.getLocation().add(0.5, 0.5, 0.5),
                    plugin.giveItem(id, 1));
        }
    }
}
