package net.skyfull.blocks;

import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * SkyfullBlocks — 8 custom, placeable & breakable crate blocks for the SKYFULL
 * server. Pair each placed block with a CrazyCrates crate at that location.
 *
 * The plugin only needs the accompanying resource pack (blockstate + models +
 * textures for brown_mushroom_block / skyfull:block/crateN) for the blocks to
 * LOOK like crates. Without the pack they still work, they just look like
 * mushroom blocks.
 */
public final class SkyfullBlocks extends JavaPlugin {

    /** PDC key stored on the give-item so we know which crate it places. */
    public static NamespacedKey CRATE_KEY;

    @Override
    public void onEnable() {
        CRATE_KEY = new NamespacedKey(this, "crate");
        getServer().getPluginManager().registerEvents(new BlockListener(this), this);
        getLogger().info("SkyfullBlocks povoleno – " + CrateBlocks.COUNT + " crate bloku pripraveno.");
    }

    /** Builds the item that, when placed, becomes crate block #id. */
    public ItemStack giveItem(int id, int amount) {
        ItemStack it = new ItemStack(Material.BROWN_MUSHROOM_BLOCK, Math.max(1, amount));
        ItemMeta meta = it.getItemMeta();
        meta.displayName(LegacyComponentSerializer.legacySection()
                .deserialize(CrateBlocks.name(id))
                .decoration(TextDecoration.ITALIC, false));
        meta.getPersistentDataContainer().set(CRATE_KEY, PersistentDataType.INTEGER, id);
        // Make the inventory icon show the crate model (needs resource pack).
        try {
            meta.setItemModel(new NamespacedKey("skyfull", "crate" + id));
        } catch (Throwable ignored) {
            // Older API without setItemModel: icon stays a mushroom block, still works.
        }
        it.setItemMeta(meta);
        return it;
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender,
                             org.bukkit.command.Command command,
                             String label, String[] args) {
        if (!sender.hasPermission("skyfull.blocks.admin")) {
            sender.sendMessage("§cNemas opravneni.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("§b/sblocks give <1-8> [hrac] §7| §blist");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "list" -> {
                sender.sendMessage("§bSKYFULL crate bloky:");
                for (int i = 1; i <= CrateBlocks.COUNT; i++) {
                    sender.sendMessage(" §7#" + i + " " + CrateBlocks.name(i));
                }
            }
            case "give" -> {
                if (args.length < 2) { sender.sendMessage("§cPouziti: /sblocks give <1-8> [hrac]"); return true; }
                int id;
                try { id = Integer.parseInt(args[1]); }
                catch (NumberFormatException e) { sender.sendMessage("§cCislo 1-8."); return true; }
                if (!CrateBlocks.valid(id)) { sender.sendMessage("§cCislo musi byt 1-8."); return true; }

                org.bukkit.entity.Player target;
                if (args.length >= 3) {
                    target = getServer().getPlayerExact(args[2]);
                    if (target == null) { sender.sendMessage("§cHrac neni online."); return true; }
                } else if (sender instanceof org.bukkit.entity.Player p) {
                    target = p;
                } else {
                    sender.sendMessage("§cZ konzole zadej i jmeno hrace.");
                    return true;
                }
                target.getInventory().addItem(giveItem(id, 1));
                sender.sendMessage("§aPredano: " + CrateBlocks.name(id) + " §7-> §f" + target.getName());
            }
            default -> sender.sendMessage("§b/sblocks give <1-8> [hrac] §7| §blist");
        }
        return true;
    }
}
